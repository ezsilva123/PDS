# 2. Descrição Textual: Realizar Pix

**Atores:** Cliente (Primário), Sistema BACEN (Secundário)

**Pré-condições:**
1. O Cliente deve estar autenticado (logado) no aplicativo IFBank.
2. O Cliente deve possuir saldo disponível em conta igual ou superior ao valor da transferência desejada.

**Fluxo Principal (FP):**
1. O Cliente acessa a Área Pix no aplicativo e seleciona a opção "Transferir".
2. O Cliente digita a Chave Pix de destino.
3. O Sistema envia os dados para o Sistema BACEN solicitando a validação da chave informada.
4. O Sistema BACEN confirma a existência da chave e retorna os dados do recebedor.
5. O Sistema exibe os dados do recebedor na tela para conferência do Cliente e solicita o valor.
6. O Cliente digita o valor desejado e confirma a operação.
7. O Sistema solicita à Conta do cliente a verificação do saldo.
8. O Sistema confirma que há saldo suficiente e debita o valor da Conta do Cliente.
9. O Sistema gera uma nova Transação (Pix) e salva no extrato da Conta.
10. O Sistema exibe o comprovante da transação com sucesso na tela do Cliente.

**Fluxos de Exceção (FE):**
* **[FE-01] Chave Pix Inválida** *(Ocorre no Passo 4 do FP)*
  1. O Sistema BACEN informa que a chave informada não existe ou está inativa.
  2. O Sistema exibe um alerta na tela: "Chave Pix não encontrada. Verifique os dados e tente novamente".
  3. O fluxo retorna ao Passo 2 do FP.
* **[FE-02] Saldo Insuficiente** *(Ocorre no Passo 7 do FP)*
  1. A Conta informa ao sistema que o saldo atual é inferior ao valor da transferência.
  2. O Sistema interrompe a operação de débito.
  3. O Sistema exibe um alerta na tela: "Saldo insuficiente para realizar esta transferência".
  4. O fluxo é encerrado.
