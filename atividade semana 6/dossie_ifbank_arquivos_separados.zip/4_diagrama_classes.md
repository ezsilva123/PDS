# 4. Diagrama de Classes

```mermaid
classDiagram
    class Cliente {
        - String nome
        - String cpf
        - String senha
        + autenticar(senha: String) Boolean
    }

    class Conta {
        - String numero
        - String agencia
        - Double saldo
        + verificarSaldo(valor: Double) Boolean
        + debitar(valor: Double) void
        + creditar(valor: Double) void
        + registrarTransacao(valor: Double, tipo: String) void
    }

    class Transacao {
        - String idTransacao
        - Double valor
        - Date data
        - String tipo
        + gerarComprovante() String
    }

    class ChavePix {
        - TipoChave tipo
        - String valor
        - Date dataCadastro
        - String status
        + ativar() void
        + inativar() void
    }

    class TipoChave {
        <<enumeration>>
        CPF
        CNPJ
        EMAIL
        TELEFONE
        ALEATORIA
    }

    Cliente "1" -- "1..*" Conta : possui >
    Conta "1" -- "0..*" Transacao : possui extrato de >
    Conta "1" -- "0..*" ChavePix : tem cadastradas >
    ChavePix --> TipoChave : categorizada por >
```
