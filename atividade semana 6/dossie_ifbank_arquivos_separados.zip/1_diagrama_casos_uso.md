# 1. Diagrama de Casos de Uso

```mermaid
flowchart LR
    C((Cliente))
    B((Sistema BACEN))

    subgraph App IFBank
        UC1([Autenticar Usuário])
        UC2([Consultar Saldo])
        UC3([Cadastrar Chave Pix])
        UC4([Realizar Pix])
    end

    C --- UC2
    C --- UC3
    C --- UC4

    UC2 -. "<< include >>" .-> UC1
    UC3 -. "<< include >>" .-> UC1
    UC4 -. "<< include >>" .-> UC1

    UC4 --- B
```
