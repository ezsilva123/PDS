# 3. Diagrama de Sequência (Realizar Pix)

```mermaid
sequenceDiagram
    actor Cliente
    participant :TelaPix
    participant :ControladorPix
    participant :Conta
    participant :SistemaBACEN

    Cliente->>:TelaPix: 1. Informa Chave Pix de destino
    :TelaPix->>:ControladorPix: 2. validarChave(chave)
    :ControladorPix->>:SistemaBACEN: 3. consultarChave(chave)
    :SistemaBACEN-->>:ControladorPix: 4. Retorna dados do recebedor
    :ControladorPix-->>:TelaPix: 5. Envia dados para conferência
    :TelaPix-->>Cliente: 6. Exibe dados e solicita valor
    Cliente->>:TelaPix: 7. Informa valor e confirma
    :TelaPix->>:ControladorPix: 8. processarPix(valor)
    :ControladorPix->>:Conta: 9. verificarSaldo(valor)

    alt Saldo Suficiente
        :Conta-->>:ControladorPix: 10a. Retorna true (Aprovado)
        :ControladorPix->>:Conta: 11a. debitar(valor)
        :Conta-->>:ControladorPix: 12a. Débito processado
        :ControladorPix->>:Conta: 13a. registrarTransacao(valor, "PIX")
        :ControladorPix-->>:TelaPix: 14a. Sucesso na transação
        :TelaPix-->>Cliente: 15a. Exibe Comprovante
    else Saldo Insuficiente
        :Conta-->>:ControladorPix: 10b. Retorna false (Reprovado)
        :ControladorPix-->>:TelaPix: 11b. Erro: Saldo Insuficiente
        :TelaPix-->>Cliente: 12b. Exibe Mensagem "Saldo Insuficiente"
    end
```
